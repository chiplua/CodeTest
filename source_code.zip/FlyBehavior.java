package headfirst.strategy;

public interface FlyBehavior {
	public void fly();
}
